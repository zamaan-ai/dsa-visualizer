import { useState } from 'react';
import SortingView from './views/SortingView.jsx';
import LinearView from './views/LinearView.jsx';
import TreeView from './views/TreeView.jsx';
import GraphView from './views/GraphView.jsx';

const TABS = [
  ['sort', 'Sorting', SortingView],
  ['linear', 'Linear structures', LinearView],
  ['tree', 'Binary search tree', TreeView],
  ['graph', 'Graph', GraphView],
];

export default function App() {
  const [tab, setTab] = useState('sort');
  const View = TABS.find(t => t[0] === tab)[2];
  return (
    <>
      <header>
        <h1>DSA Visualizer</h1>
        <nav>
          {TABS.map(([k, label]) => (
            <button key={k} className={k === tab ? 'on' : ''} onClick={() => setTab(k)}>{label}</button>
          ))}
        </nav>
      </header>
      <main><View key={tab} /></main>
    </>
  );
}
